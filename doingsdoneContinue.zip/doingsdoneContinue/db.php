<?php

        //Получение проекта
function get_project($con, $user_id) {
    $sql = "SELECT ID, Name, Author, (SELECT COUNT(*) FROM `task` WHERE `Project` = `project`.ID) AS `Quantity`  FROM `project` WHERE `Author` = ".intval($user_id);
    $result = mysqli_query($con, $sql);
    $projectz = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $projectz;
}

        //Получение задач
function get_tasks($con, $user_id) {
    $sql = "SELECT * FROM `task` WHERE `Author` = " . intval($user_id);
    $result = mysqli_query($con, $sql);
    $taskz = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $taskz;
}

        //Получение id проекта по его названию
function get_id_from_project($con, $user_id, $prjnm) {
    $sql = "SELECT ID FROM `project` WHERE `Author` = " . $user_id . " AND `Name` = '" . strval($prjnm) . "'";
    $result = mysqli_query($con, $sql);
    $idprjnm =  mysqli_fetch_all($result, MYSQLI_ASSOC);   
    if(count($idprjnm)!=0){
        $idprj =  array_column($idprjnm, 'ID');    
    	return $idprj[0];
	}
	return null;
}

//Получение задач по id проекта
function get_tasks_from_id($con, $user_id, $idprj) {
    $sql =  "SELECT * FROM `task` WHERE `Author` = ".$user_id." AND `Project` = ".$idprj;
    $result = mysqli_query($con, $sql);
    $taskz = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $taskz;
}

// $params = $_GET;
// $params['tab'] = "top";
// $params['sort'] = "desc";
// $params['update'] = 1;
// $scriptname = pathinfo(__FILE__, PATHINFO_BASENAME);
// $query = http_build_query($params);
// $url = "/" . $scriptname . "?" . $query;

        //add задач
function addTask($con, $name, $file, $date_c = null, $user_id, $proj) {
    if(empty($date_c)) {$date_c = null;}; 
    print($file);
    if(empty($file)) {$file = null;}; 
    //filter_input(INPUT_POST, '',  FILTER_SANITIZE_NUMBER_INT) // FILTER_SANITIZE_SPECIAL_CHARS FILTER_SANITIZE_STRING
    $sql = "INSERT INTO `task` (`DateOfCreation`, `Completed`, `Name`, `File`, `DateOfCompletion`, `Author`, `Project`) VALUES (NOW(), 0, ?, ?, ?, ?, ?)";
    // print("INSERT INTO `task` (`DateOfCreation`, `Completed`, `Name`, `File`, `DateOfCompletion`, `Author`, `Project`) VALUES (NOW(), 0, ".$name.", ".$file.", ".$date_c.", ".$user_id.", ".$proj.")");
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'sssii', $name, $file, $date_c, $user_id, $proj);
        
    mysqli_stmt_execute($stmt);

    $res = mysqli_stmt_get_result($stmt);
        // print_r($stmt);
    // $rows = mysqli_fetch_all($res, MYSQLI_ASSOC);

    return true;
}

        
?>
